package com.lb.safewatch.controller;

import javax.servlet.ServletContext;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.lb.safewatch.model.ServiceResponse;
import com.lb.safewatch.model.StartSessionRequest;
import com.side.ofac.API.CheckAlertRequest;
import com.side.ofac.API.CheckAlertResponse;
import com.side.ofac.API.CheckDetectionRequest;
import com.side.ofac.API.CheckDetectionResponse;
import com.side.ofac.API.CreateAlertRequest;
import com.side.ofac.API.CreateAlertResponse;
import com.side.ofac.API.GoodGuyInfo;
import com.side.ofac.API.GoodGuyServerScanningServiceResponse;
import com.side.ofac.API.LoginRequest;
import com.side.ofac.API.LoginResponse;
import com.side.ofac.API.LogoutRequest;
import com.side.ofac.API.LogoutResponse;
import com.side.ofac.API.ScanRequest;
import com.side.ofac.API.ScanResponse;
import com.side.ofac.API.SideApi;
import com.side.ofac.API.UpdateAlertRequest;
import com.side.ofac.API.UpdateAlertResponse;

@RestController
@RequestMapping("/")
public class SafeWatchController {

	Logger logger = Logger.getLogger(SafeWatchController.class);

	@Autowired(required = true)
	private SideApi api;
	@Autowired(required = true)
	private ServletContext context;

	@RequestMapping(value = "/logIn", method = RequestMethod.POST)
	public ServiceResponse<LoginResponse> login(
			@RequestBody LoginRequest loginRequest) {
		LoginResponse response = new LoginResponse();
		int responseCode = api.SoLogin(loginRequest, response);
		return new ServiceResponse<LoginResponse>(responseCode,
				getLastErrorTextByCode(responseCode), response);
	}

	@RequestMapping(value = "/logOut", method = RequestMethod.POST)
	public ServiceResponse<LogoutResponse> logOut(
			@RequestBody LogoutRequest logOutRequest) {
		LogoutResponse response = new LogoutResponse();
		int responsecode = api.SoLogout(logOutRequest, response);
		return new ServiceResponse<LogoutResponse>(responsecode,
				getLastErrorTextByCode(responsecode), null);
	}

	@RequestMapping(value = "/startScanSession", method = RequestMethod.POST)
	public ServiceResponse<Integer> startScanSession(
			@RequestBody StartSessionRequest startSessionRequest) {
		int responseCode = api.SoStartScanSession(
				startSessionRequest.getSzApplication(),
				startSessionRequest.getFormatName(),
				startSessionRequest.getDataSource());
		return new ServiceResponse<Integer>(responseCode,
				getLastErrorTextByCode(responseCode), responseCode);
	}

	@RequestMapping(value = "/endScanSession", method = RequestMethod.POST)
	public ServiceResponse<LogoutResponse> endScanSession(
			@RequestBody LogoutRequest logOutRequest) {
		LogoutResponse response = new LogoutResponse();
		int responseCode = api.SoEndScanSession(logOutRequest, response);
		return new ServiceResponse<LogoutResponse>(responseCode,
				getLastErrorTextByCode(responseCode), response);
	}

	@RequestMapping(value = "/scan", method = RequestMethod.POST)
	public ServiceResponse<ScanResponse> scan(
			@RequestBody ScanRequest scanRequest) {
		ScanResponse response = new ScanResponse();
		int responseCode = api.SoScan(scanRequest, response);
		return new ServiceResponse<ScanResponse>(responseCode,
				getLastErrorTextByCode(responseCode), response);
	}

	@RequestMapping(value = "/createAlert", method = RequestMethod.POST)
	public ServiceResponse<CreateAlertResponse> createAlert(
			@RequestBody CreateAlertRequest createAlertRequest) {
		CreateAlertResponse response = new CreateAlertResponse();
		int responseCode = api.SoCreateAlert(createAlertRequest, response);
		return new ServiceResponse<CreateAlertResponse>(responseCode,
				getLastErrorTextByCode(responseCode), response);
	}

	@RequestMapping(value = "/checkAlert", method = RequestMethod.POST)
	public ServiceResponse<CheckAlertResponse> checkAlert(
			@RequestBody CheckAlertRequest checkAlertRequest) {
		CheckAlertResponse response = new CheckAlertResponse();
		int responseCode = api.SoCheckAlert(checkAlertRequest, response);
		return new ServiceResponse<CheckAlertResponse>(responseCode,
				getLastErrorTextByCode(responseCode), response);
	}

	@RequestMapping(value = "/checkDetection", method = RequestMethod.POST)
	public ServiceResponse<CheckDetectionResponse> checkDetection(
			@RequestBody CheckDetectionRequest checkDetectionRequest) {
		CheckDetectionResponse response = new CheckDetectionResponse();
		int responseCode = api
				.SoCheckDetection(checkDetectionRequest, response);
		return new ServiceResponse<CheckDetectionResponse>(responseCode,
				getLastErrorTextByCode(responseCode), response);
	}

	@RequestMapping(value = "/updateAlert", method = RequestMethod.POST)
	public ServiceResponse<UpdateAlertResponse> updateAlert(
			@RequestBody UpdateAlertRequest updateAlertRequest) {
		UpdateAlertResponse response = new UpdateAlertResponse();
		int responseCode = api.SoUpdateAlert(updateAlertRequest, response);
		return new ServiceResponse<UpdateAlertResponse>(responseCode,
				getLastErrorTextByCode(responseCode), response);
	}

	@RequestMapping(value = "/addGoodGuy", method = RequestMethod.POST)
	public ServiceResponse<GoodGuyServerScanningServiceResponse> addGoodGuy(
			@RequestBody GoodGuyInfo goodGuyInfo) {
		GoodGuyServerScanningServiceResponse response = new GoodGuyServerScanningServiceResponse();
		String result = api.SoAddGoodGuy(goodGuyInfo, response);
		return new ServiceResponse<GoodGuyServerScanningServiceResponse>(
				result.equals("success") ? 0 : -1,
				getLastErrorTextByCode(result), response);
	}

	@RequestMapping(value = "/getLastErrorText", method = RequestMethod.GET)
	public String getLastErrorText() {
		String errorText = api.getLastErrorText();
		return errorText;
	}

	@RequestMapping(value = "/getLastErrorCode", method = RequestMethod.GET)
	public int getLastErrorCode() {
		int errorCode = api.getLastErrorCode();
		return errorCode;
	}

	private String getLastErrorTextByCode(int errorCode) {
		if (errorCode == 0)
			return null;
		return api.getLastErrorText();
	}

	private String getLastErrorTextByCode(String errorCodeString) {
		if (errorCodeString.equals("success"))
			return null;
		return api.getLastErrorText();
	}

}
