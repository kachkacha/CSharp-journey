package com.lb.safewatch.util;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.lb.safewatch.model.ServiceResponse;
import com.side.ofac.API.LoginRequest;
import com.side.ofac.API.LoginResponse;
import com.side.ofac.API.SideApi;

public class SessionBasedLoginInterceptor implements HandlerInterceptor {

	Logger logger = Logger.getLogger(SessionBasedLoginInterceptor.class);

	@Autowired(required = true)
	private LoginRequest loginRequest;
	@Autowired(required = true)
	private SideApi api;

	@Override
	public boolean preHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler) throws Exception {
		HttpSession session = request.getSession(true);
		if (!session.isNew()) {
			logger.info("session is alive, we dont want login");
			return true;
		} else {
			logger.info("session is dead or it is first visit, we need to login first");
			return login(request, response);
		}
	}

	@Override
	public void postHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
	}

	@Override
	public void afterCompletion(HttpServletRequest request,
			HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
	}

	private boolean login(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		logger.info("Starting login...");
		LoginResponse loginResponse = new LoginResponse();
		String path = request.getSession().getServletContext().getRealPath(
				loginRequest.getLoginFile());
		if (path != null)
			loginRequest.setLoginFile(path);
		int loginResultCode = api.SoLogin(loginRequest, loginResponse);

		if (loginResultCode != 0) {
			logger.info("Login failed...");
			ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
			String json = ow.writeValueAsString(new ServiceResponse<LoginResponse>(
							loginResultCode, api.getLastErrorText(),
							loginResponse));
			response.getWriter().write(json);
			logger.error("Response from login" + json);
			request.getSession().invalidate();
			return false;
		}
		logger.info("Login succeed");
		return true;
	}
}
