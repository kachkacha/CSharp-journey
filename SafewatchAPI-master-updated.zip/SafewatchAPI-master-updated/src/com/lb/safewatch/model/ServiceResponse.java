package com.lb.safewatch.model;

public class ServiceResponse<T> {

	private int errorCode;
	private String errorText;
	private T value;

	public ServiceResponse() {
		
	}

	public ServiceResponse(int errorCode, String errorText, T value) {
		this.errorCode = errorCode;
		this.errorText = errorText;
		this.value = value;
	}

	public int getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorText() {
		return errorText;
	}

	public void setErrorText(String errorText) {
		this.errorText = errorText;
	}

	public T getValue() {
		return value;
	}

	public void setValue(T value) {
		this.value = value;
	}
}
