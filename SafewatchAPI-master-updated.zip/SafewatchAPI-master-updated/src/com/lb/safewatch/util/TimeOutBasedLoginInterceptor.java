package com.lb.safewatch.util;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.joda.time.Duration;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.lb.safewatch.model.ServiceResponse;
import com.side.ofac.API.LoginRequest;
import com.side.ofac.API.LoginResponse;
import com.side.ofac.API.SideApi;

public class TimeOutBasedLoginInterceptor implements HandlerInterceptor {

	private static Logger logger = Logger
			.getLogger(TimeOutBasedLoginInterceptor.class);

	private static final int treshHold = 1 * 1000; // 1 minute
	private static final long TIME_OUT = 30 * 60 * 1000 - treshHold; // 29
																		// minute
	private static DateTime lastRequestTime = DateTime.now().minusYears(1);

	private static LoginRequest loginRequest;
	private static SideApi api;

	@Override
	public boolean preHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler) throws Exception {
		return checkAndLogin(request, response);
	}

	@Override
	public void postHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {

	}

	@Override
	public void afterCompletion(HttpServletRequest request,
			HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
	}

	private synchronized static boolean checkAndLogin(
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		logger.info("Last Request time : " + lastRequestTime);
		DateTime currentRequestTime = DateTime.now();
		logger.info("Current Request time : " + currentRequestTime);
		Duration duration = new Duration(lastRequestTime, currentRequestTime);
		logger.info("Duration in minutes : " + duration.getStandardMinutes());
		long elipsedMilis = duration.getMillis();
		if (elipsedMilis < TIME_OUT) {
			logger.info("Logged in... Login is nnot required");
			return true;
		}
		logger.info("Not Logged in... Login is required");
		return login(request, response);
	}

	private static boolean login(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		logger.info("Starting login... ");
		LoginResponse loginResponse = new LoginResponse();
		String path = request.getSession().getServletContext()
				.getRealPath(loginRequest.getLoginFile());
		if (path != null)
			loginRequest.setLoginFile(path);
		int loginResultCode = api.SoLogin(loginRequest, loginResponse);
		if (loginResultCode != 0) {
			logger.error("Login failed...");
			ObjectWriter ow = new ObjectMapper().writer()
					.withDefaultPrettyPrinter();
			String json = ow
					.writeValueAsString(new ServiceResponse<LoginResponse>(
							loginResultCode, api.getLastErrorText(),
							loginResponse));
			response.getWriter().write(json);
			logger.error(json);
			return false;
		}
		lastRequestTime = DateTime.now();
		logger.info("Login succeed");
		return true;
	}

	public static LoginRequest getLoginRequest() {
		return loginRequest;
	}

	public static void setLoginRequest(LoginRequest loginRequest) {
		TimeOutBasedLoginInterceptor.loginRequest = loginRequest;
	}

	public static SideApi getApi() {
		return api;
	}

	public static void setApi(SideApi api) {
		TimeOutBasedLoginInterceptor.api = api;
	}
}
