package com.lb.safewatch.util;

import java.io.File;
import java.io.IOException;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;

import org.apache.log4j.FileAppender;
import org.apache.log4j.Layout;
import org.apache.log4j.helpers.LogLog;
import org.apache.log4j.spi.LoggingEvent;
import org.joda.time.DateTime;

/***
 * 
 * @author davit.chkhaidze
 *
 */
public class MyDailyAppender extends FileAppender {

	private String scheduledFilename;
	private long nextCheck = System.currentTimeMillis() - 1;

	private DateTime now = new DateTime();

	RollingCalendar rc = new RollingCalendar();

	static final TimeZone gmtTimeZone = TimeZone.getTimeZone("GMT");

	public MyDailyAppender() {
	}

	public MyDailyAppender(Layout layout, String filename, String datePattern)
			throws IOException {
		super(layout, filename, true);
		activateOptions();
	}

	public void activateOptions() {
		if (fileName != null) {
			File file = new File(fileName);
			DateTime fileModifedDate = new DateTime(file.lastModified());
			String folderNameDate = fileModifedDate.toString("dd-MM-yyyy");
			String fileNameHour = String
					.valueOf(fileModifedDate.getHourOfDay());
			scheduledFilename = String.format(fileName, folderNameDate,
					fileNameHour);

		} else {
			LogLog.error("Either File or DatePattern options are not set for appender ["
					+ name + "].");
		}

		super.activateOptions();
	}

	void rollOver() throws IOException {

		String datedFilename = String.format(fileName,
				now.toString("dd-MM-yyyy"), String.valueOf(now.getHourOfDay()));
		if (scheduledFilename.equals(datedFilename)) {
			return;
		}
		this.closeFile();
		File target = new File(scheduledFilename);
		if (target.exists()) {
			target.delete();
		}

		File file = new File(fileName);
		boolean result = file.renameTo(target);
		if (result) {
			LogLog.debug(fileName + " -> " + scheduledFilename);
		} else {
			LogLog.error("Failed to rename [" + fileName + "] to ["
					+ scheduledFilename + "].");
		}

		try {
			// This will also close the file. This is OK since multiple
			// close operations are safe.
			this.setFile(fileName, false, this.bufferedIO, this.bufferSize);
		} catch (IOException e) {
			errorHandler.error("setFile(" + fileName + ", false) call failed.");
		}
		scheduledFilename = datedFilename;
	}

	protected void subAppend(LoggingEvent event) {
		long n = System.currentTimeMillis();
		if (n >= nextCheck) {
			now = new DateTime();
			nextCheck = rc.getNextCheckMillis(now);
			try {
				rollOver();
			} catch (IOException ioe) {
				LogLog.error("rollOver() failed.", ioe);
			}
		}
		super.subAppend(event);
	}
}


class RollingCalendar extends GregorianCalendar {
	private static final long serialVersionUID = -3560331770601814177L;

	RollingCalendar() {
		super();
	}

	RollingCalendar(TimeZone tz, Locale locale) {
		super(tz, locale);
	}

	public long getNextCheckMillis(DateTime now) {
		return getNextCheckDate(now).getTime();
	}

	public Date getNextCheckDate(DateTime now) {
		this.setTime(now.toDate());
		this.set(Calendar.MINUTE, 0);
		this.set(Calendar.SECOND, 0);
		this.set(Calendar.MILLISECOND, 0);
		this.add(Calendar.HOUR_OF_DAY, 1);
		return getTime();
	}
}
