package com.lb.safewatch.util;

import com.fasterxml.jackson.core.JsonParser.Feature;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JacksonObjectMapperEx extends ObjectMapper{

	private static final long serialVersionUID = 1L;

	public JacksonObjectMapperEx(){
		configure(Feature.ALLOW_UNQUOTED_FIELD_NAMES, true);
	}
}
