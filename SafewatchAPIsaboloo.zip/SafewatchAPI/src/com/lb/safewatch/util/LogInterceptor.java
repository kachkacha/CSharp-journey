package com.lb.safewatch.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

public class LogInterceptor implements HandlerInterceptor {

	private static final Logger logger = Logger.getLogger(LogInterceptor.class);

	@Override
	public boolean preHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler) throws Exception {
		logger.info("\n\n");
		logActionName(request);
		logMethod(request);
		logProxyIpAddress(request);
		logRealIpAddress(request);
		logParameters(request);
		return true;
	}

	@Override
	public void postHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		logResponse(response);
	}

	@Override
	public void afterCompletion(HttpServletRequest request,
			HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		if (ex != null)
			logger.error(ex);
		else {
			logger.info("Success");
		}
	}

	private static void logActionName(HttpServletRequest request) {
		String path = request.getPathInfo();
		int lastSlash = path.lastIndexOf('/');
		String actionName = path.substring(lastSlash);
		logger.info(actionName);
	}

	private static void logProxyIpAddress(HttpServletRequest request) {
		String address = request.getRemoteAddr();
		logger.info(address);
	}

	private static void logRealIpAddress(HttpServletRequest request) {
		String ipAddress = request.getHeader("X-FORWARDED-FOR");
		if (ipAddress == null) {
			logProxyIpAddress(request);
		} else
			logger.info(ipAddress);
	}

	private static void logParameters(HttpServletRequest request) {
		try {
			String theString = getStringFromInputStream(request
					.getInputStream());
			logger.info(theString);
		} catch (IOException e) {
		}
	}

	private static void logMethod(HttpServletRequest request) {
		String method = request.getMethod();
		logger.info(method);
	}

	private static void logResponse(HttpServletResponse response) {
		try {
			String resp = response.getOutputStream().toString();
			logger.info(resp);
		} catch (IOException e) {
		}
	}

	private static String getStringFromInputStream(InputStream is) {
		BufferedReader br = null;
		StringBuilder sb = new StringBuilder();
		String line;
		try {
			br = new BufferedReader(new InputStreamReader(is));
			while ((line = br.readLine()) != null) {
				sb.append(line);
			}
		} catch (IOException e) {
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
				}
			}
		}
		return sb.toString();

	}
}
