package com.lb.safewatch.model;

public class StartSessionRequest {

	private String szApplication;
	private String formatName;
	private String dataSource;

	public StartSessionRequest() {
	}

	public String getSzApplication() {
		return szApplication;
	}

	public void setSzApplication(String szApplication) {
		this.szApplication = szApplication;
	}

	public String getFormatName() {
		return formatName;
	}

	public void setFormatName(String formatName) {
		this.formatName = formatName;
	}

	public String getDataSource() {
		return dataSource;
	}

	public void setDataSource(String dataSource) {
		this.dataSource = dataSource;
	}
}